#Creating 3 Volunteer users

INSERT INTO Volunteer (VolunteerID, FirstName, LastName, Email, IsAdmin, TimeStamp)
VALUES (1, 'Bob', 'Ross', 'BobbyRoss@Gmail.com', 0, '2018-02-28 04:53:00');

INSERT INTO Volunteer (VolunteerID, FirstName, LastName, Email, IsAdmin, TimeStamp)
VALUES (2, 'Elon', 'Musk', 'Spaceman22@Gmail.com', 0, '2018-02-28 02:53:00');

INSERT INTO Volunteer (VolunteerID, FirstName, LastName, Email, IsAdmin, TimeStamp)
VALUES (3, 'Tom', 'Thompson', 'CMack@Gmail.com', 0, '2018-02-28 12:53:00');

#Registering existing users into the credentials table

INSERT INTO VolunteerCredentials(VCredentialsID, Username, Password, VolunteerID)
VALUES (1, 'BobbyRoss', 'ILove2Paint!', 1);

INSERT INTO VolunteerCredentials(VCredentialsID, Username, Password, VolunteerID)
VALUES (2, 'TeslaInSpace', 'HeavyPa55word!', 2);

INSERT INTO VolunteerCredentials(VCredentialsID, Username, Password, VolunteerID)
VALUES (3, 'BoringUsername', '5trongPassword!', 3);




select * from Volunteer;

select * from VolunteerCredentials;







