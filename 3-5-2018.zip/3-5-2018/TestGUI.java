package DAO;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class TestGUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername = new JTextField();
	private JTextField txtPassword = new JTextField();
	private JLabel lblPassword = new JLabel("");
	private JButton btnValidate = new JButton("Validate");
	
	TestConnection signal = new TestConnection(); //Instantiates connection class that contains createConnection() method
	
	private final JLabel lblNewLabel = new JLabel("Enter Password:"); //Enter password label
	private final JLabel label = new JLabel("Enter Username:"); //Enter user name label
	private final JButton txtClear = new JButton("Clear");
	private final JButton btnExit = new JButton("Exit");
	private final JLabel lblUsername = new JLabel("");
	private final JLabel lblResults = new JLabel("RESULTS");
	private final JLabel testUsername = new JLabel("BobbyRoss");
	private final JLabel testPassword = new JLabel("ILove2Paint!");
	private final JLabel lblNewLabel_1 = new JLabel("Test these credentials!");
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TestGUI frame = new TestGUI();
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TestGUI() 
	{
		
//-> Create Frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 677, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
//------
		
		
//--> Create Username Textbox
		txtUsername.setBounds(175, 38, 143, 26);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
//------
		
		
//--> Create Password Textbox
		txtPassword.setBounds(175, 98, 143, 26);
		contentPane.add(txtPassword);
		txtPassword.setColumns(10);
		lblPassword.setForeground(Color.BLUE);
//-----
		
		
//--> Create Password Label
		lblPassword.setBounds(6, 226, 127, 16);
		contentPane.add(lblPassword);
		
		
		btnValidate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					selectUsername(signal.createConnection(), null); //Calling this method will validate whether or not a valid username has been entered
					selectPassword(signal.createConnection(), null);//Calling this method will validate whether or not a valid password has been entered
				
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
//-----
		
//--> Create Validate Button
		btnValidate.setBounds(187, 172, 127, 29);
		contentPane.add(btnValidate);
		lblNewLabel.setBounds(64, 103, 134, 16);
		
		contentPane.add(lblNewLabel);
		label.setBounds(64, 38, 134, 16);
		
		contentPane.add(label);
		txtClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				
				txtUsername.setText("");
				txtPassword.setText("");
				lblUsername.setText("");
				lblPassword.setText("");
			}
		});
		txtClear.setBounds(187, 213, 127, 29);
		
		contentPane.add(txtClear);
		
		
		
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				System.exit(0);
			}
		});
		btnExit.setBounds(511, 243, 127, 29);
		
		contentPane.add(btnExit);
		lblUsername.setForeground(Color.BLUE);
		lblUsername.setBounds(6, 198, 127, 16);
		
		contentPane.add(lblUsername);
		lblResults.setFont(new Font("LiHei Pro", Font.BOLD, 13));
		lblResults.setBounds(31, 177, 73, 16);
		
		contentPane.add(lblResults);
		testUsername.setBounds(372, 177, 80, 16);
		
		contentPane.add(testUsername);
		testPassword.setBounds(516, 177, 95, 16);
		
		contentPane.add(testPassword);
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		lblNewLabel_1.setBounds(384, 112, 192, 53);
		
		contentPane.add(lblNewLabel_1);
//------
	}
	
	/**
	 * 
	 * @param signal
	 * @param AttDraft
	 * @throws SQLException
	 * 
	 * This method populates a select query's where clause based on user input. The select statement searches for 
	 * a Username string within the VolunteerCredentials table, then returns a message stating whether or not the Username is valid
	 * 
	 */
	public void selectUsername(Connection signal, String AttDraft) throws SQLException
	{
		Statement stmt = null; //Set Statement class variable to null
		String query = ("Select Username FROM VolunteerCredentials WHERE Username = "); //SQL Select statement
		String userInput = txtUsername.getText();	 
		query += "'" + userInput + "'"; //Populate WHERE clause with userInput
		try 
		{
			stmt = signal.createStatement(); // This line creates the Statement object for database communication 
			ResultSet rs = stmt.executeQuery(query); // This line creates a ResultSet object then argues the query string that contains the select statement
			
			//Loop through the result set to pull strings out that are needed in order to execute the query string
			
			if (rs.getRow() == 0) 
			{
				lblUsername.setText("Username Failure!");
				lblUsername.setForeground(Color.RED);
			}
			
			while (rs.next()) 
			{
				String grab = rs.getString("Username");
				
				if (grab != null && userInput != null) 
				{
					if (grab.equals(userInput)) 
					{
						lblUsername.setText("Username Success!");		
						lblUsername.setForeground(Color.BLUE);
					}
				}
								
			}
			
		} catch (SQLException e) {
			System.out.println(e); //Output exception type
		} finally {
			if (stmt != null) {  stmt.close(); } //Close query statement
		}
		
		signal.close(); //Close Database connection
	}
	
	/**
	 * 
	 * @param signal
	 * @param AttDraft
	 * @throws SQLException
	 * 
	 * This method populates a select query's where clause based on user input. The select statement searches for 
	 * a Password string within the VolunteerCredentials table, then returns a message stating whether or not the Password is valid
	 * 
	 */
	public void selectPassword(Connection signal, String AttDraft) throws SQLException
	{
		Statement stmt = null; //Set Statement class variable to null
		
		String query = ("Select Password FROM VolunteerCredentials WHERE Password = "); //SQL Select statement
		String userInput = txtPassword.getText();	
		query += "'" + userInput + "'"; //Populate WHERE clause with userInput
		try 
		{
			stmt = signal.createStatement(); // This line creates the Statement object for database communication 
			ResultSet rs = stmt.executeQuery(query); // This line creates a ResultSet object then argues the query string that contains the select statement
			
			//Loop through the result set to pull strings out that are needed in order to execute the query string
			
			if (rs.getRow()==0) 
			{
				lblPassword.setText("Password Failure!");		
				lblPassword.setForeground(Color.RED);
			}
			while (rs.next()) 
			{
				String grab = rs.getString("Password");
				
				if (grab != null && userInput != null) 
				{
					if(grab.equalsIgnoreCase(userInput)) 
					{
						lblPassword.setText("Password Success!");
						lblPassword.setForeground(Color.BLUE);
					}
					
				}
				else
					lblPassword.setText("Failed.");
			}
						
		} catch (SQLException e) {
			System.out.println(e); //Output exception type
		} finally {
			if (stmt != null) {  stmt.close(); } //Close query statement
		}
		
		signal.close(); //Close Database connection
	}
}
